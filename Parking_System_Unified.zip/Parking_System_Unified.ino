/* =====================================================================
   IoT-Based Automated Circular Underground Car Parking System
   Team CREVIOTICS  |  Team ID: RH-0036

   UNIFIED FIRMWARE
   -----------------------------------------------------------------
   This file merges the three separate device firmwares from the
   project (Entry ESP32-CAM, Entry Gate ESP32, Exit Gate ESP32) into
   a single source file using a role selector. Each physical board
   still needs to be flashed individually — pick the matching role
   below, compile, and upload to that board only.

   Roles:
     ROLE_CAM   -> ESP32-CAM (AI-Thinker). Used at BOTH the entry and
                   exit points — flash this same code to both camera
                   boards. It exposes /capture and pushes the photo
                   to Telegram.
     ROLE_ENTRY -> Entry gate ESP32. Ultrasonic + IR detection, gate
                   + rotation servos, LCD status, triggers the entry
                   camera, and syncs available slot count to Exit.
     ROLE_EXIT  -> Exit gate ESP32. Same as Entry plus RFID card
                   verification before releasing the vehicle, and
                   syncs the slot count back to Entry.

   IMPORTANT — hardcoded WiFi password and Telegram bot token are
   carried over from the original files for parity. For anything
   beyond a bench prototype, move these into a separate secrets.h
   (excluded from version control) instead of leaving them in the
   main sketch.
   ===================================================================== */

// ------------------------- SELECT ROLE HERE -------------------------
#define ROLE_CAM   1
#define ROLE_ENTRY 2
#define ROLE_EXIT  3

#define DEVICE_ROLE ROLE_ENTRY   // <-- change to ROLE_CAM / ROLE_ENTRY / ROLE_EXIT per board
// ----------------------------------------------------------------------


// =====================================================================
// SHARED WIFI CREDENTIALS (all boards join the same network)
// =====================================================================
const char* ssid     = "HomeFi";
const char* password = "12341234";


#if DEVICE_ROLE == ROLE_CAM
/* =====================================================================
   ROLE_CAM — ESP32-CAM (AI-Thinker)
   Flash this exact code onto BOTH the entry and exit camera boards.
   Each board gets its DHCP IP; that IP is what you enter as camIP in
   the ENTRY / EXIT gate controller sections below.
   ===================================================================== */

#include "esp_camera.h"
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <WebServer.h>

// ---- Telegram ----
String BOTtoken = "8942736047:AAFlPms44WtwlPEtLQ9U5QeHzWcKSTp5gcI";
String CHAT_ID  = "7169747260";

WiFiClientSecure clientTCP;
WebServer server(80);

// ---- AI-Thinker camera pins ----
#define PWDN_GPIO_NUM   32
#define RESET_GPIO_NUM  -1
#define XCLK_GPIO_NUM    0
#define SIOD_GPIO_NUM   26
#define SIOC_GPIO_NUM   27
#define Y9_GPIO_NUM     35
#define Y8_GPIO_NUM     34
#define Y7_GPIO_NUM     39
#define Y6_GPIO_NUM     36
#define Y5_GPIO_NUM     21
#define Y4_GPIO_NUM     19
#define Y3_GPIO_NUM     18
#define Y2_GPIO_NUM      5
#define VSYNC_GPIO_NUM  25
#define HREF_GPIO_NUM   23
#define PCLK_GPIO_NUM   22

void startCamera() {
  camera_config_t config;
  config.ledc_channel = LEDC_CHANNEL_0;
  config.ledc_timer   = LEDC_TIMER_0;
  config.pin_d0 = Y2_GPIO_NUM;
  config.pin_d1 = Y3_GPIO_NUM;
  config.pin_d2 = Y4_GPIO_NUM;
  config.pin_d3 = Y5_GPIO_NUM;
  config.pin_d4 = Y6_GPIO_NUM;
  config.pin_d5 = Y7_GPIO_NUM;
  config.pin_d6 = Y8_GPIO_NUM;
  config.pin_d7 = Y9_GPIO_NUM;
  config.pin_xclk  = XCLK_GPIO_NUM;
  config.pin_pclk  = PCLK_GPIO_NUM;
  config.pin_vsync = VSYNC_GPIO_NUM;
  config.pin_href  = HREF_GPIO_NUM;
  config.pin_sscb_sda = SIOD_GPIO_NUM;
  config.pin_sscb_scl = SIOC_GPIO_NUM;
  config.pin_pwdn  = PWDN_GPIO_NUM;
  config.pin_reset = RESET_GPIO_NUM;
  config.xclk_freq_hz = 20000000;
  config.pixel_format  = PIXFORMAT_JPEG;

  if (psramFound()) {
    config.frame_size   = FRAMESIZE_VGA;
    config.jpeg_quality = 10;
    config.fb_count      = 2;
  } else {
    config.frame_size   = FRAMESIZE_QVGA;
    config.jpeg_quality = 12;
    config.fb_count      = 1;
  }

  esp_err_t err = esp_camera_init(&config);
  if (err != ESP_OK) {
    Serial.print("Camera Init Failed: ");
    Serial.println(err);
    while (true);
  }
  Serial.println("Camera Ready");
}

String sendPhotoTelegram() {
  camera_fb_t *fb = esp_camera_fb_get();
  if (!fb) {
    Serial.println("Camera Capture Failed");
    return "CAPTURE FAILED";
  }

  Serial.println("Connecting to Telegram...");
  clientTCP.setInsecure();
  if (!clientTCP.connect("api.telegram.org", 443)) {
    Serial.println("Telegram Connection Failed");
    esp_camera_fb_return(fb);
    return "CONNECTION FAILED";
  }
  Serial.println("Connected to Telegram");

  String head = "--ESP32CAM\r\n"
                "Content-Disposition: form-data; name=\"chat_id\";\r\n\r\n"
                + CHAT_ID +
                "\r\n--ESP32CAM\r\n"
                "Content-Disposition: form-data; name=\"photo\"; filename=\"capture.jpg\"\r\n"
                "Content-Type: image/jpeg\r\n\r\n";
  String tail = "\r\n--ESP32CAM--\r\n";

  uint32_t imageLen = fb->len;
  uint32_t totalLen = head.length() + imageLen + tail.length();

  clientTCP.println("POST /bot" + BOTtoken + "/sendPhoto HTTP/1.1");
  clientTCP.println("Host: api.telegram.org");
  clientTCP.println("Content-Length: " + String(totalLen));
  clientTCP.println("Content-Type: multipart/form-data; boundary=ESP32CAM");
  clientTCP.println();
  clientTCP.print(head);

  uint8_t *fbBuf = fb->buf;
  size_t fbLen = fb->len;
  for (size_t n = 0; n < fbLen; n += 1024) {
    if (n + 1024 < fbLen) {
      clientTCP.write(fbBuf, 1024);
      fbBuf += 1024;
    } else {
      size_t remainder = fbLen - n;
      clientTCP.write(fbBuf, remainder);
    }
  }
  clientTCP.print(tail);
  esp_camera_fb_return(fb);
  Serial.println("Photo Sent");

  unsigned long timeout = millis();
  while (clientTCP.connected() && millis() - timeout < 10000) {
    while (clientTCP.available()) {
      String line = clientTCP.readStringUntil('\n');
      Serial.println(line);
      timeout = millis();
    }
  }
  clientTCP.stop();
  return "OK";
}

void handleCapture() {
  Serial.println("Capture Request Received");
  String result = sendPhotoTelegram();
  server.send(200, "text/plain", result);
}

void setup() {
  Serial.begin(115200);
  Serial.println();

  WiFi.begin(ssid, password);
  Serial.print("Connecting WiFi");
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println();
  Serial.println("WiFi Connected");
  Serial.print("IP Address: ");
  Serial.println(WiFi.localIP());

  startCamera();

  server.on("/capture", HTTP_GET, handleCapture);
  server.begin();
  Serial.println("HTTP Server Started");
  Serial.println("Ready...");
}

void loop() {
  server.handleClient();
}


#elif DEVICE_ROLE == ROLE_ENTRY
/* =====================================================================
   ROLE_ENTRY — Entry gate ESP32 controller
   ===================================================================== */

#include <WiFi.h>
#include <HTTPClient.h>
#include <Wire.h>
#include <ESP32Servo.h>
#include <WebServer.h>
#include <hd44780.h>
#include <hd44780ioClass/hd44780_I2Clcd.h>

hd44780_I2Clcd lcd(0x3E);
WebServer server(80);

// ---- Static IP for this board ----
IPAddress local_IP(10, 230, 41, 150);
IPAddress gateway(10, 230, 41, 1);
IPAddress subnet(255, 255, 255, 0);

// ---- Peer device IPs ----
String camIP     = "10.230.41.162";  // Entry ESP32-CAM
String exitESP_IP = "10.230.41.151"; // Exit gate ESP32

// ---- Pins ----
#define TRIG_PIN      12
#define ECHO_PIN      13
#define IR_PIN        14
#define GATE_SERVO    15
#define ROTATE_SERVO  18

Servo gateServo;
Servo rotateServo;

int availableSlots = 4;
bool carDetected = false;

float readDistance() {
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);
  long duration = pulseIn(ECHO_PIN, HIGH, 30000);
  return duration * 0.034 / 2.0;
}

void updateLCD() {
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("ENTRY SYSTEM");
  lcd.setCursor(0, 1);
  lcd.print("SLOTS:");
  lcd.print(availableSlots);
}

void triggerCamera() {
  HTTPClient http;
  String url = "http://" + camIP + "/capture";
  Serial.println(url);
  http.begin(url);
  int httpCode = http.GET();
  Serial.print("HTTP CODE: ");
  Serial.println(httpCode);
  if (httpCode > 0) Serial.println(http.getString());
  http.end();
}

void sendSlotToExit() {
  HTTPClient http;
  String url = "http://" + exitESP_IP + "/update?slots=" + String(availableSlots);
  Serial.println(url);
  http.begin(url);
  int httpCode = http.GET();
  Serial.print("EXIT HTTP: ");
  Serial.println(httpCode);
  http.end();
}

void handleSlotUpdate() {
  if (server.hasArg("slots")) {
    availableSlots = server.arg("slots").toInt();
    Serial.print("UPDATED SLOTS: ");
    Serial.println(availableSlots);
    updateLCD();
    server.send(200, "text/plain", "OK");
  }
}

void rotateServoAction() {
  for (int i = 0; i < 4; i++) {
    rotateServo.write(10);
    delay(300);
    rotateServo.write(0);
    delay(300);
  }
}

void openGate() {
  Serial.println("OPENING GATE");
  gateServo.write(90);
  rotateServoAction();
  delay(5000);
  gateServo.write(0);
  Serial.println("GATE CLOSED");
}

void setup() {
  Serial.begin(115200);

  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
  pinMode(IR_PIN, INPUT);

  Wire.begin(21, 22);

  int status = lcd.begin(16, 2);
  if (status) {
    Serial.print("LCD FAILED: ");
    Serial.println(status);
    while (1);
  }
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("CONNECT WIFI");

  gateServo.attach(GATE_SERVO);
  rotateServo.attach(ROTATE_SERVO);
  gateServo.write(0);
  rotateServo.write(0);

  WiFi.config(local_IP, gateway, subnet);
  WiFi.begin(ssid, password);
  Serial.print("Connecting WiFi");
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println();
  Serial.println("WiFi Connected");
  Serial.print("ENTRY IP: ");
  Serial.println(WiFi.localIP());

  server.on("/update", handleSlotUpdate);
  server.begin();
  Serial.println("ENTRY SERVER STARTED");

  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("WIFI CONNECTED");
  delay(2000);
  updateLCD();
}

void loop() {
  server.handleClient();
  float distance = readDistance();
  Serial.print("Distance: ");
  Serial.println(distance);

  if (availableSlots <= 0) {
    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print("PARKING FULL");
    lcd.setCursor(0, 1);
    lcd.print("WAIT EXIT");
    delay(1000);
    return;
  }

  if (distance < 20 && !carDetected) {
    carDetected = true;
    Serial.println("CAR DETECTED");
    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print("CAR DETECTED");
    lcd.setCursor(0, 1);
    lcd.print("CAPTURING...");
    triggerCamera();
    delay(2000);
  }

  if (carDetected) {
    if (digitalRead(IR_PIN) == LOW) {
      Serial.println("IR DETECTED");
      lcd.clear();
      lcd.setCursor(0, 0);
      lcd.print("ACCESS GRANTED");

      if (availableSlots > 0) {
        availableSlots--;
        sendSlotToExit();
      }
      updateLCD();

      openGate();
      carDetected = false;
    }
  }
  delay(100);
}


#elif DEVICE_ROLE == ROLE_EXIT
/* =====================================================================
   ROLE_EXIT — Exit gate ESP32 controller (adds RFID verification)
   ===================================================================== */

#include <WiFi.h>
#include <HTTPClient.h>
#include <Wire.h>
#include <SPI.h>
#include <MFRC522.h>
#include <ESP32Servo.h>
#include <WebServer.h>
#include <hd44780.h>
#include <hd44780ioClass/hd44780_I2Clcd.h>

hd44780_I2Clcd lcd(0x3E);
WebServer server(80);

// ---- Static IP for this board ----
IPAddress local_IP(10, 230, 41, 151);
IPAddress gateway(10, 230, 41, 1);
IPAddress subnet(255, 255, 255, 0);

// ---- Peer device IPs ----
String entryESP_IP = "10.230.41.150"; // Entry gate ESP32
String camIP       = "10.230.41.170"; // Exit ESP32-CAM

// ---- Pins ----
#define TRIG_PIN      25
#define ECHO_PIN      26
#define IR_PIN        27
#define GATE_SERVO    32
#define ROTATE_SERVO  33
#define SS_PIN         5
#define RST_PIN        4

MFRC522 rfid(SS_PIN, RST_PIN);
Servo gateServo;
Servo rotateServo;

int availableSlots = 4;
bool carDetected = false;
bool rfidVerified = false;

// ---- Registered RFID tags ----
String validUIDs[4] = { "930C0007", "2544E206", "4426E106", "05AD4D06" };
String carNames[4]  = { "Volkswagan", "Hundai", "Toyota", "BMW" };

float readDistance() {
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);
  long duration = pulseIn(ECHO_PIN, HIGH, 30000);
  return duration * 0.034 / 2.0;
}

void updateLCD() {
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("EXIT SYSTEM");
  lcd.setCursor(0, 1);
  lcd.print("SLOTS:");
  lcd.print(availableSlots);
}

void sendSlotToEntry() {
  HTTPClient http;
  String url = "http://" + entryESP_IP + "/update?slots=" + String(availableSlots);
  Serial.println(url);
  http.begin(url);
  int httpCode = http.GET();
  Serial.print("ENTRY HTTP: ");
  Serial.println(httpCode);
  http.end();
}

void handleSlotUpdate() {
  if (server.hasArg("slots")) {
    availableSlots = server.arg("slots").toInt();
    Serial.print("UPDATED SLOTS: ");
    Serial.println(availableSlots);
    updateLCD();
    server.send(200, "text/plain", "OK");
  }
}

void triggerCamera() {
  HTTPClient http;
  String url = "http://" + camIP + "/capture";
  Serial.println(url);
  http.begin(url);
  int httpCode = http.GET();
  Serial.print("HTTP CODE: ");
  Serial.println(httpCode);
  if (httpCode > 0) Serial.println(http.getString());
  http.end();
}

void rotateServoAction() {
  int angle = availableSlots * 20;
  if (angle > 80) angle = 80;
  Serial.print("Rotate Servo Angle: ");
  Serial.println(angle);
  rotateServo.write(angle);
  delay(1000);
}

void openGate() {
  Serial.println("OPENING GATE");
  gateServo.write(90);
  rotateServoAction();
  delay(5000);
  gateServo.write(0);
  Serial.println("GATE CLOSED");
}

bool checkRFID() {
  if (!rfid.PICC_IsNewCardPresent()) return false;
  if (!rfid.PICC_ReadCardSerial()) return false;

  String uid = "";
  for (byte i = 0; i < rfid.uid.size; i++) {
    if (rfid.uid.uidByte[i] < 0x10) uid += "0";
    uid += String(rfid.uid.uidByte[i], HEX);
  }
  uid.toUpperCase();
  Serial.print("UID: ");
  Serial.println(uid);

  for (int i = 0; i < 4; i++) {
    if (uid == validUIDs[i]) {
      lcd.clear();
      lcd.setCursor(0, 0);
      lcd.print("WELCOME");
      lcd.setCursor(0, 1);
      lcd.print(carNames[i]);
      delay(2000);
      return true;
    }
  }

  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("INVALID CARD");
  delay(2000);
  updateLCD();
  return false;
}

void setup() {
  Serial.begin(115200);

  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
  pinMode(IR_PIN, INPUT);

  Wire.begin(21, 22);

  int status = lcd.begin(16, 2);
  if (status) {
    Serial.print("LCD FAILED: ");
    Serial.println(status);
    while (1);
  }
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("CONNECT WIFI");

  gateServo.attach(GATE_SERVO);
  rotateServo.attach(ROTATE_SERVO);
  gateServo.write(0);
  rotateServo.write(0);

  SPI.begin();
  rfid.PCD_Init();
  Serial.println("RFID READY");

  WiFi.config(local_IP, gateway, subnet);
  WiFi.begin(ssid, password);
  Serial.print("Connecting WiFi");
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println();
  Serial.println("WiFi Connected");
  Serial.print("EXIT IP: ");
  Serial.println(WiFi.localIP());

  server.on("/update", handleSlotUpdate);
  server.begin();
  Serial.println("EXIT SERVER STARTED");

  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("WIFI CONNECTED");
  delay(2000);
  updateLCD();
}

void loop() {
  server.handleClient();
  float distance = readDistance();
  Serial.print("Distance: ");
  Serial.println(distance);

  if (distance < 20 && !carDetected) {
    carDetected = true;
    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print("SCAN RFID");
    lcd.setCursor(0, 1);
    lcd.print("TO EXIT");
    Serial.println("CAR DETECTED");
  }

  if (carDetected && !rfidVerified) {
    if (checkRFID()) {
      rfidVerified = true;
      Serial.println("RFID VERIFIED");
      lcd.clear();
      lcd.setCursor(0, 0);
      lcd.print("CAPTURING...");
      triggerCamera();
      delay(2000);
    }
  }

  if (carDetected && rfidVerified) {
    if (digitalRead(IR_PIN) == LOW) {
      Serial.println("IR DETECTED");
      lcd.clear();
      lcd.setCursor(0, 0);
      lcd.print("EXIT GRANTED");

      if (availableSlots < 4) {
        availableSlots++;
        sendSlotToEntry();
      }
      updateLCD();

      openGate();
      carDetected = false;
      rfidVerified = false;
    }
  }
  delay(100);
}

#else
  #error "Set DEVICE_ROLE to ROLE_CAM, ROLE_ENTRY, or ROLE_EXIT before compiling."
#endif
