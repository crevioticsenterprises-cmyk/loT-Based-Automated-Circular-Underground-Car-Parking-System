// Converted from Entry cam.pdf
// Copy the extracted code from the PDF into this sketch.
