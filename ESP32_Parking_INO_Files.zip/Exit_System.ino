// Converted from Exit ESP32.pdf
// Copy the extracted code from the PDF into this sketch.
