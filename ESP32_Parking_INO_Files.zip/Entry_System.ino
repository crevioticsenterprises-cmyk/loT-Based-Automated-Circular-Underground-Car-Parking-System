// Converted from Entry System.pdf
// Copy the extracted code from the PDF into this sketch.
